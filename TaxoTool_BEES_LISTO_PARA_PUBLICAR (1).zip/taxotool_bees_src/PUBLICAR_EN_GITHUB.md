# Publicar TaxoTool BEES

Este proyecto ya está preparado para GitHub Pages.

## Paso 1
En GitHub crea un repositorio nuevo llamado `taxotool-bees`.

Recomendado:
- Visibility: **Public** si quieres que cualquiera con el enlace pueda abrirlo.
- No agregues README, .gitignore ni licencia al crearlo.

## Paso 2
Sube el contenido de esta carpeta a la rama `main`.

## Paso 3
En el repositorio abre **Settings > Pages** y en **Build and deployment > Source** selecciona **GitHub Actions**.

## Paso 4
El workflow `Deploy TaxoTool to GitHub Pages` compilará y publicará automáticamente la app.

La URL normalmente quedará con esta estructura:
`https://TU-USUARIO.github.io/taxotool-bees/`

## Importante
Esta versión no requiere Gemini ni login Firebase para usar TaxoTool.
