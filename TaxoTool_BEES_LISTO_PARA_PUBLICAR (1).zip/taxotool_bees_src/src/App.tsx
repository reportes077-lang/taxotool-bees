import { useState, useEffect } from "react";
import { 
  Zap,
  Calendar,
  Target,
  Tag,
  Copy,
  Check,
  Layers,
  Grid,
  Award,
  Plus,
  X,
  Smartphone,
  Globe,
  Hash,
  Image as ImageIcon,
  Link as LinkIcon,
  Code,
  ChevronLeft,
  ChevronRight,
  FileText,
  Download,
  Sun,
  Moon,
  User as UserIcon,
} from "lucide-react";
import { 
  PRIMARY_OBJECTIVES, 
  SUB_TAGS, 
  ACTIVATIONS, 
  ACTIVATION_CODES, 
  CATEGORIES, 
  CATEGORY_CODES,
  BRANDS_BY_CATEGORY,
  BRAND_CODES,
  FORMATS,
  FORMAT_CODES,
  CAMPAIGN_TYPES,
  OPTIONAL_DEEPLINKS
} from "./constants";
import { SKU_DATA, SkuInfo } from "./lib/skuData";
import { motion, AnimatePresence } from "motion/react";

const BEES_LOGO = "https://www.bees.com/themes/custom/abinbev_propel/bees-logo-black.svg";

const ALL_BRANDS_UNIQUE = Array.from(new Set(Object.values(BRANDS_BY_CATEGORY).flat())).sort();

export default function App() {
  const user = { displayName: "Acceso directo", email: "TaxoTool local", photoURL: null as string | null };

  // Get today's date in GMT-5 (America/Bogota)
  const getTodayGMT5 = () => {
    const date = new Date();
    const bogotaDate = new Intl.DateTimeFormat('en-CA', {
      timeZone: 'America/Bogota',
      year: 'numeric',
      month: '2-digit',
      day: '2-digit'
    }).format(date);
    return bogotaDate; // Returns YYYY-MM-DD
  };

  const [startDate, setStartDate] = useState(getTodayGMT5());
  const [endDate, setEndDate] = useState("");
  const [campaignName, setCampaignName] = useState("");
  const [taskNumber, setTaskNumber] = useState("");
  const [primaryObjective, setPrimaryObjective] = useState("");
  const [subTag, setSubTag] = useState("");
  const [activation, setActivation] = useState("");
  const [category, setCategory] = useState("");
  const [brands, setBrands] = useState<string[]>([""]);
  const [campaignType, setCampaignType] = useState("");
  const [skus, setSkus] = useState<string[]>([""]);
  const [selectedFormats, setSelectedFormats] = useState<string[]>([]);
  const [isX2, setIsX2] = useState(false);
  const [previewImageType, setPreviewImageType] = useState<"legal" | "only">("only");
  
  const [copiedTaxo, setCopiedTaxo] = useState(false);
  const [copiedTags, setCopiedTags] = useState(false);
  const [copiedExcel, setCopiedExcel] = useState(false);
  const [copiedSummary, setCopiedSummary] = useState(false);
  const [currentSkuIndex, setCurrentSkuIndex] = useState(0);
  const [selectedOptionalDeeplink, setSelectedOptionalDeeplink] = useState("");
  const [copiedOptional, setCopiedOptional] = useState(false);
  const [darkMode, setDarkMode] = useState(() => {
    if (typeof window !== 'undefined') {
      return localStorage.getItem('theme') === 'dark' || 
             (!localStorage.getItem('theme') && window.matchMedia('(prefers-color-scheme: dark)').matches);
    }
    return false;
  });

  useEffect(() => {
    if (darkMode) {
      document.documentElement.classList.add('dark');
      localStorage.setItem('theme', 'dark');
    } else {
      document.documentElement.classList.remove('dark');
      localStorage.setItem('theme', 'light');
    }
  }, [darkMode]);

  // Reset carousel index when SKUs change
  useEffect(() => {
    setCurrentSkuIndex(0);
  }, [skus.length]);

  // Handle conditional defaults and resets
  useEffect(() => {
    setSubTag("");
    if (primaryObjective && primaryObjective !== "commercial") {
      setActivation("n/a");
      setCategory("null");
    } else if (primaryObjective === "commercial") {
      setActivation("");
      setCategory("");
    } else {
      setActivation("");
      setCategory("");
    }
  }, [primaryObjective]);

  // Reset brands when category changes
  useEffect(() => {
    setBrands([""]);
  }, [category]);

  const formatMenuLabel = (str: string) => {
    if (!str) return "";
    if (str === "n/a") return "n/a";
    if (str === "mktp") return "Marketplace";
    return str
      .split("_")
      .map(word => word.charAt(0).toUpperCase() + word.slice(1).toLowerCase())
      .join(" ");
  };

  const formatDate = (dateStr: string) => {
    if (!dateStr) return "";
    const [year, month, day] = dateStr.split("-");
    return `${day}/${month}/${year}`;
  };

  const formatDateShort = (dateStr: string) => {
    if (!dateStr) return "";
    const [year, month, day] = dateStr.split("-");
    return `${day}/${month}/${year.slice(-2)}`;
  };

  const getDateFormattedMMM = (dateStr: string) => {
    if (!dateStr) return "00XXX00";
    const [year, month, day] = dateStr.split("-");
    const months = ["JAN", "FEB", "MAR", "APR", "MAY", "JUN", "JUL", "AUG", "SEP", "OCT", "NOV", "DEC"];
    const monthMMM = months[parseInt(month) - 1] || "XXX";
    return `${day}${monthMMM}${year.slice(-2)}`;
  };

  const toggleFormat = (format: string) => {
    setSelectedFormats(prev => 
      prev.includes(format) 
        ? prev.filter(f => f !== format) 
        : [...prev, format]
    );
  };

  const handleAddSku = () => {
    if (skus.length < 50) {
      setSkus([...skus, ""]);
    }
  };

  const handleRemoveSku = (index: number) => {
    setSkus(skus.filter((_, i) => i !== index));
  };

  const handleSkuChange = (index: number, value: string) => {
    const numericValue = value.replace(/\D/g, "");
    const newSkus = [...skus];
    newSkus[index] = numericValue;
    setSkus(newSkus);
  };

  const handleAddBrand = () => {
    if (brands.length < 10) {
      setBrands([...brands, ""]);
    }
  };

  const handleRemoveBrand = (index: number) => {
    setBrands(brands.filter((_, i) => i !== index));
  };

  const handleBrandChange = (index: number, value: string) => {
    const newBrands = [...brands];
    newBrands[index] = value;
    setBrands(newBrands);
  };

  const generateTaxonomy = () => {
    // Count filled fields to check if at least 3 are present
    const fields = [
      campaignName, 
      taskNumber, 
      primaryObjective, 
      subTag, 
      activation, 
      category, 
      brands.filter(b => b && b !== "n/a").join(""), 
      campaignType,
      selectedFormats.length > 0 ? "formats" : ""
    ];
    const filledCount = fields.filter(f => f && f !== "n/a" && f !== "null").length;
    
    if (filledCount < 3) return "";

    const buCode = "COL";
    const primaryCode = primaryObjective ? primaryObjective.substring(0, 3).toUpperCase() : "NA";
    const subCode = subTag ? subTag.substring(0, 3).toUpperCase() : "NA";
    const typeCode = category ? (category === "mktp" ? "1P" : "1P") : "NA";
    const activationCode = activation ? (ACTIVATION_CODES[activation] || "NA") : "NA";
    const categoryCode = category ? (CATEGORY_CODES[category] || "NA") : "NA";
    
    // Brand Logic for Taxonomy
    const activeBrands = brands.filter(b => b && b !== "" && b !== "n/a");
    let brandCode = "NA";
    if (activeBrands.length === 1) {
      brandCode = BRAND_CODES[activeBrands[0]] || "NA";
    } else if (activeBrands.length > 1) {
      brandCode = "MULTIBRAND";
    }
    
    // Campaign Name & Task Number & Campaign Type Part
    const formattedTask = taskNumber ? `#${taskNumber}` : "#0000";
    const formattedType = campaignType ? campaignType.toUpperCase() : "NA";
    const formattedName = campaignName.trim().replace(/\s+/g, "-").toUpperCase() || "SIN-NOMBRE";
    const namePart = `${formattedTask}/${formattedType}/${formattedName}`;

    // Format Logic
    let formatPart = "NA";
    if (selectedFormats.length > 0) {
      const type = (selectedFormats.length > 1 || isX2) ? "CANV" : "CAMP";
      const siglas = FORMATS
        .filter(f => selectedFormats.includes(f))
        .map(f => FORMAT_CODES[f])
        .join("");
      formatPart = `${type}-${siglas}`;
    }

    const startFormatted = formatDateShort(startDate);
    
    const parts = [buCode, primaryCode, subCode, typeCode, activationCode, categoryCode, brandCode, namePart, formatPart];
    
    if (startFormatted) parts.push(startFormatted);
    
    return parts.join("_");
  };

  const generateBrazeTags = () => {
    const tags: { text: string; type: 'standard' | 'sku' }[] = [];
    
    // Campaign Type Tag
    if (campaignType) {
      tags.push({ text: `campaign_type/${campaignType}`.toLowerCase(), type: 'standard' });
    }

    // Primary/Sub Tag
    if (primaryObjective && subTag) {
      tags.push({ text: `${primaryObjective}/${subTag}`.toLowerCase(), type: 'standard' });
    }
    
    // Activation Tag (Only for Commercial)
    if (primaryObjective === "commercial" && activation) {
      tags.push({ text: `activation/${activation}`.toLowerCase(), type: 'standard' });
    }

    // Category Tag (Only for Commercial or if specifically selected)
    if (category && (primaryObjective === "commercial" || category !== "null")) {
      tags.push({ text: `category/${category}`.toLowerCase(), type: 'standard' });
    }

    // Brand Tags
    const activeBrands = brands.filter(b => b && b !== "" && b !== "n/a");
    if (activeBrands.length === 1) {
      tags.push({ text: `brand/${activeBrands[0]}`.toLowerCase(), type: 'standard' });
    } else if (activeBrands.length > 1) {
      tags.push({ text: "brand/multimarca", type: 'standard' });
      activeBrands.forEach(b => {
        tags.push({ text: `brand/${b}`.toLowerCase(), type: 'standard' });
      });
    }

    // Channel Tags
    if (selectedFormats.length === 1 && !isX2) {
      tags.push({ text: `channel/${selectedFormats[0].replace(" ", "_")}`.toLowerCase(), type: 'standard' });
    } else if (selectedFormats.length > 1 || isX2) {
      tags.push({ text: "channel/canvas", type: 'standard' });
    }

    // SKU Tags
    skus.filter(s => s.trim() !== "").forEach(s => {
      tags.push({ text: `sku/${s}`, type: 'sku' });
    });

    // Marketplace logic: add paid/media if certain conditions are met
    const isMarketplace = 
      campaignType === "marketplace" || 
      (primaryObjective === "commercial" && subTag === "marketplace") ||
      category === "mktp";

    if (isMarketplace) {
      tags.push({ text: "paid/media", type: 'standard' });
    }
    
    return tags;
  };

  const generateExcelRow = () => {
    const taskNum = taskNumber || "NA";
    const campName = campaignName || "NA";
    const taxonomy = generateTaxonomy();
    const campType = campaignType || "NA";
    
    // Formato DD/MM/YYYY asegurando que no haya espacios
    const start = formatDate(startDate).trim();
    const end = (formatDate(endDate) || "N/A").trim();
    
    const obj = primaryObjective || "NA";
    const sub = subTag || "NA";
    const act = activation || "NA";
    const cat = category || "NA";
    const brd = brands.filter(b => b.trim() !== "").join(";") || "NA";
    const skuList = skus.filter(s => s.trim() !== "").join(";") || "NA";
    const channel = (selectedFormats.length > 1 || isX2) ? "CANVAS" : (selectedFormats.length === 1 ? "CAMPAÑA" : "NA");
    const formatsNames = selectedFormats.join(";");
    
    // Generar tags en formato (TAG1);(TAG2).
    const brazeTags = generateBrazeTags();
    const formattedTags = brazeTags.map(t => `(${t.text})`).join(";");

    // Construimos la fila asegurando el orden pedido por el usuario
    const fields = [
      taskNum,        // # TAREA
      campName,       // NOMBRE CAMPAÑA
      taxonomy,       // TAXONOMIA
      campType,       // CAMPAIGN_TYPE
      start,          // FECHA INICIO
      end,            // FECHA FIN
      obj,            // PRIMARY OBJECTIVE
      sub,            // SUBTAG
      act,            // ACTIVATION
      cat,            // CATEGORY
      brd,            // BRAND
      skuList,        // SKUS
      channel,        // CHANNEL
      formatsNames,   // FORMATOS
      formattedTags   // TAGS
    ];

    // Limpiamos cada campo: Todo a MAYÚSCULAS, remover tabulaciones y espacios extra
    const rowData = fields.map(v => {
      let val = String(v).toUpperCase().trim();
      // Eliminar tabulaciones o saltos internos
      val = val.replace(/[\t\n\r]/g, " ");
      // Envolver con comillas dobles para que Excel respete los slashes y no los tome como separadores
      return `"${val}"`;
    });

    return rowData.join("\t");
  };

  const getSelectedSkuDetails = () => {
    return skus
      .map(s => SKU_DATA.find(d => d.sku === s))
      .filter(Boolean) as SkuInfo[];
  };

  const generateLiquidCode = (selectedSkus: SkuInfo[]) => {
    const skuVal = selectedSkus.length > 0 ? selectedSkus.map(s => s.sku).join(";") : "N/A";
    const catVal = (category || "N/A").toUpperCase();
    const activeBrands = brands.filter(b => b && b !== "" && b !== "n/a");
    const brandVal = activeBrands.length > 0 ? activeBrands.join(";") : "N/A";

    const commonAttributes = `{% assign regional = custom_attribute.\${bees_regional} | default: 'NULL'%}\n` +
      `{% assign gerencia = custom_attribute.\${bees_gerencia} %}\n` +
      `{% assign subchannel = custom_attribute.\${bees_subcanal} %}\n` +
      `{% assign bees_unidadnegocio = custom_attribute.\${bees_unidadnegocio} %}`;

    // CASE 1: COMMERCIAL
    if (primaryObjective === "commercial") {
      return `{% assign sku = "${skuVal}" %}\n` +
        `{% assign priority = "N/A" %}\n` +
        `{% assign category = "${catVal}" %}\n` +
        `{% assign promo = "N/A" %}\n` +
        `{% assign marca =  "${brandVal}" %}\n` +
        `{% assign partner = "N/A" %}\n` +
        `${commonAttributes}\n\n` +
        `XXXXX\n\n` +
        `{{content_blocks.\${message_extras_trade25}}}`;
    }

    // CASE 3: MARKETPLACE CAMPAIGNS (when not commercial but type is marketplace)
    if (campaignType === "marketplace") {
      return `${commonAttributes}\n` +
        `{% assign marca = "N/A" %}\n` +
        `{% assign partner = "N/A" %}\n` +
        `{% assign automated = 1 %}\n` +
        `{% assign personalized = 1 %}\n` +
        `{% assign ident = "N/A" %}\n\n` +
        `XXXXX\n\n` +
        `{{content_blocks.\${message_extras_marketplace}}}`;
    }

    // CASE 2: NORMAL AWARENESS
    return `${commonAttributes}\n` +
      `{% assign automated = 1 %}\n` +
      `{% assign personalized = 1 %}\n` +
      `{% assign ident = "N/A" %}\n` +
      `{% assign marca = "N/A" %}\n\n` +
      `XXXXX\n\n` +
      `{{content_blocks.\${message_extras_awareness}}}`;
  };

  const generateSummary = () => {
    const isBold = true;
    const b = (text: string) => isBold ? `*${text}*` : text;

    const taxonomyText = generateTaxonomy() || "ESPERANDO SELECCIÓN...";
    const tagsText = generateBrazeTags().map(t => t.text.toLowerCase()).join("\n") || "ESPERANDO SELECCIÓN...";
    const liquidText = generateLiquidCode(getSelectedSkuDetails());

    // Campaign Name & Task Number & Campaign Type Part
    const formattedTask = taskNumber ? `#${taskNumber}` : "#0000";
    const formattedType = (campaignType || "NA").toUpperCase().replace(/\s+/g, "-");
    const formattedName = campaignName.trim().replace(/\s+/g, "-").toUpperCase() || "SIN-NOMBRE";
    const dateFormatted = getDateFormattedMMM(startDate);
    
    const commonPrefix = `CO_${formattedTask}_${formattedType}_${formattedName}_${dateFormatted}`;
    const summaryTitle = `✏️ ${formattedTask} | ${formattedType} | ${formattedName} | ${dateFormatted}`;

    const skuDetails = getSelectedSkuDetails();
    let recursosText = "SIN SKUS SELECCIONADOS";

    if (skuDetails.length > 0) {
      const groupedResources: string[] = [];
      
      // Sort SKUs by brand link to keep them together in the summary
      const sortedSkus = [...skuDetails].sort((a, b) => {
        const linkA = a.deeplinkBrand || "ZZZ";
        const linkB = b.deeplinkBrand || "ZZZ";
        return linkA.localeCompare(linkB);
      });

      // Group SKUs by brand link to avoid repeats if they have the same brand link
      const processedBrandLinks = new Set<string>();

      sortedSkus.forEach((sku) => {
        const brandUrl = sku.deeplinkBrand || "No Brand";
        
        // If this brand hasn't been shown yet, show it
        if (!processedBrandLinks.has(brandUrl) && brandUrl !== "No Brand") {
          let brandName = "Marca";
          const sortedBrandNames = [...ALL_BRANDS_UNIQUE].sort((a, b) => b.length - a.length);
          for (const bName of sortedBrandNames) {
            if (sku.name.toLowerCase().includes(bName.toLowerCase())) {
              brandName = bName;
              break;
            }
          }
          
          groupedResources.push(`${brandName.toUpperCase()}`);
          groupedResources.push(`${brandUrl}`);
          processedBrandLinks.add(brandUrl);
        }

        // Show SKU info
        groupedResources.push(`${sku.sku} - ${sku.name}`);
        groupedResources.push(`${sku.deeplink}`);
        groupedResources.push(`${sku.imgCrudo || "N/A"}`);
        groupedResources.push(`${sku.imgBees || "N/A"}\n`);
      });
      
      recursosText = groupedResources.join("\n").trim();
    }

    const flightText = `${formatDate(startDate)} - ${formatDate(endDate) || "SIN FIN"}`;

    let summaryParts = [
      summaryTitle,
      `${b("TAXONOMIA BRAZE")}\n${taxonomyText}`,
      `${b("FLIGHT")}\n${flightText}`,
      `${b("TAGS BRAZE")}\n${tagsText}`,
      `${b("RECURSOS")}\n${recursosText}`,
      `${b("MESSAGE EXTRA")}\n${liquidText}`
    ];

    if (selectedFormats.includes("WhatsApp")) {
      summaryParts.push(`${b("LINK DINÁMICO (WHATSAPP)")}\nhttps://brz.ai/`);
      summaryParts.push(`${b("NOMBRE PLANTILLA WHATSAPP")}\n${commonPrefix}`);
    }

    if (selectedOptionalDeeplink) {
      summaryParts.push(`${b("DEEPLINK OPCIONAL")}\n${selectedOptionalDeeplink}`);
    }

    summaryParts.push(`${b("NOMBRE BASE DE DATOS")}\n${commonPrefix} .csv`);

    return summaryParts.join("\n\n---------------------------\n\n");
  };

  const handleDownloadTxt = () => {
    const summary = generateSummary();
    const formattedName = campaignName.trim().replace(/\s+/g, "-").toUpperCase() || "SIN-NOMBRE";
    const formattedType = (campaignType || "NA").toUpperCase().replace(/\s+/g, "-");
    const dateFormatted = getDateFormattedMMM(startDate);
    
    const fileName = `CO_#${taskNumber || "0000"}_${formattedType}_${formattedName}_${dateFormatted}.txt`;
    
    const element = document.createElement("a");
    const file = new Blob([summary], {type: 'text/plain'});
    element.href = URL.createObjectURL(file);
    element.download = fileName;
    document.body.appendChild(element);
    element.click();
    document.body.removeChild(element);
  };

  const taxonomy = generateTaxonomy();
  const brazeTags = generateBrazeTags();
  const excelRow = generateExcelRow();
  const selectedSkuDetails = getSelectedSkuDetails();
  const liquidCode = generateLiquidCode(selectedSkuDetails);

  const copyToClipboard = async (text: string, setCopied: (v: boolean) => void) => {
    try {
      if (navigator.clipboard && window.isSecureContext) {
        await navigator.clipboard.writeText(text);
        setCopied(true);
        setTimeout(() => setCopied(false), 2000);
      } else {
        const textArea = document.createElement("textarea");
        textArea.value = text;
        textArea.style.position = "fixed";
        textArea.style.left = "-9999px";
        textArea.style.top = "0";
        document.body.appendChild(textArea);
        textArea.focus();
        textArea.select();
        document.execCommand('copy');
        document.body.removeChild(textArea);
        setCopied(true);
        setTimeout(() => setCopied(false), 2000);
      }
    } catch (err) {
      console.error("Failed to copy: ", err);
    }
  };

  return (
    <div className={`min-h-screen transition-colors duration-300 ${darkMode ? 'bg-[#0F0F0F] text-gray-100' : 'bg-[#F8F9FA] text-[#1A1A1A]'} font-sans`}>
      {/* Header */}
      <header className={`${darkMode ? 'bg-[#1A1A1A] border-gray-800' : 'bg-white border-gray-200'} border-b px-6 py-4 flex items-center justify-between sticky top-0 z-50 shadow-sm`}>
        <div className="flex items-center gap-3">
          <img 
            src={BEES_LOGO} 
            alt="BEES Logo" 
            className={`h-7 w-auto transition-all ${darkMode ? 'brightness-0 invert' : ''}`} 
            referrerPolicy="no-referrer" 
            onError={(e) => {
              (e.target as HTMLImageElement).src = "https://picsum.photos/seed/bees/200/200";
            }}
          />
          <div className={`h-8 w-[1px] ${darkMode ? 'bg-gray-700' : 'bg-gray-300'} mx-2`} />
          <h1 className="text-2xl font-bold tracking-tight text-[#FFD100]">
            Taxo<span className={darkMode ? 'text-white' : 'text-[#1A1A1A]'}>Tool</span>
          </h1>
          <div className={`h-8 w-[1px] ${darkMode ? 'bg-gray-700' : 'bg-gray-300'} mx-2`} />
          <img 
            src="https://www.svgrepo.com/download/353508/braze.svg" 
            alt="Braze Logo" 
            className={`h-7 w-auto transition-all ${darkMode ? 'brightness-0 invert' : ''}`} 
            referrerPolicy="no-referrer"
            onError={(e) => {
              (e.target as HTMLImageElement).src = "https://cdn.prod.website-files.com/60a4d4a53dd0c3f45579ac64/66853b2209a78da3e37b4f87_Vector.svg";
            }}
          />
        </div>
        <div className="flex items-center gap-4">
          <div className="hidden md:flex items-center gap-3 mr-4">
            <div className={`p-1 rounded-full border ${darkMode ? 'bg-gray-800 border-gray-700' : 'bg-gray-50 border-gray-200'}`}>
              {user.photoURL ? (
                <img src={user.photoURL} className="w-8 h-8 rounded-full" alt="User" referrerPolicy="no-referrer" />
              ) : (
                <div className="w-8 h-8 rounded-full bg-[#FFD100] flex items-center justify-center text-[#1A1A1A]">
                  <UserIcon size={16} />
                </div>
              )}
            </div>
            <div className="flex flex-col">
              <span className={`text-[10px] font-black uppercase leading-none ${darkMode ? 'text-[#FFD100]' : 'text-[#1A1A1A]'}`}>
                {user.displayName}
              </span>
              <span className={`text-[9px] font-medium ${darkMode ? 'text-gray-500' : 'text-gray-400'}`}>
                {user.email}
              </span>
            </div>
          </div>
          
          <div className="flex items-center gap-2">
            <button
              onClick={() => setDarkMode(!darkMode)}
              className={`p-2 rounded-xl border transition-all ${darkMode ? 'bg-gray-800 border-gray-700 text-[#FFD100] hover:bg-gray-700' : 'bg-gray-50 border-gray-200 text-gray-600 hover:bg-gray-100'}`}
              title={darkMode ? "Modo Claro" : "Modo Oscuro"}
            >
              {darkMode ? <Sun size={18} /> : <Moon size={18} />}
            </button>
          </div>
          
          <div className="hidden sm:flex items-center gap-2">
            <button 
              onClick={() => copyToClipboard(generateSummary(), setCopiedSummary)}
              className={`px-4 py-2 rounded-xl border transition-all flex items-center gap-2 text-xs font-bold shadow-sm ${darkMode ? 'bg-gray-800 border-gray-700 text-gray-200 hover:bg-gray-700' : 'bg-gray-50 border-gray-200 text-gray-700 hover:bg-gray-100'}`}
            >
              {copiedSummary ? <Check size={14} className="text-green-500" /> : <Copy size={14} />}
              {copiedSummary ? "Copiado" : "Copiar Resumen"}
            </button>
            <button 
              onClick={handleDownloadTxt}
              className="px-4 py-2 rounded-xl bg-[#FFD100] text-[#1A1A1A] hover:bg-[#e6bc00] transition-all flex items-center gap-2 text-xs font-bold shadow-sm"
            >
              <Download size={14} />
              Guardar .TXT
            </button>
          </div>
        </div>
      </header>

      <main className="max-w-7xl mx-auto p-6 grid grid-cols-1 lg:grid-cols-3 gap-8">
        {/* Left Column: Form */}
        <section className="lg:col-span-2 space-y-6">
          <div className={`${darkMode ? 'bg-[#1A1A1A] border-gray-800' : 'bg-white border-gray-100'} rounded-2xl p-8 shadow-sm border`}>
            <div className="flex items-center gap-2 mb-6">
              <Zap className="text-[#FFD100] w-5 h-5 fill-current" />
              <h2 className={`text-xl font-bold ${darkMode ? 'text-white' : 'text-[#1A1A1A]'}`}>Configuración de Campaña</h2>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              {/* BU Field (Fixed) */}
              <div>
                <label className="block">
                  <span className={`text-xs font-bold uppercase tracking-wider ${darkMode ? 'text-gray-500' : 'text-gray-400'} mb-1 block flex items-center gap-2`}>
                    <Globe size={14} /> Business Unit (BU)
                  </span>
                  <input 
                    type="text" 
                    value="Colombia" 
                    disabled 
                    className={`w-full border rounded-xl px-4 py-3 font-medium outline-none cursor-not-allowed ${darkMode ? 'bg-gray-800/50 border-gray-700 text-gray-400' : 'bg-gray-100 border-gray-200 text-gray-500'}`}
                  />
                </label>
              </div>

              {/* Campaign Type Field */}
              <div>
                <label className="block">
                  <span className={`text-xs font-bold uppercase tracking-wider ${darkMode ? 'text-gray-500' : 'text-gray-400'} mb-1 block flex items-center gap-2`}>
                    <Layers size={14} /> Campaign Type
                  </span>
                  <select 
                    value={campaignType} 
                    onChange={(e) => setCampaignType(e.target.value)}
                    className={`w-full border rounded-xl px-4 py-3 focus:ring-2 focus:ring-[#FFD100] focus:border-transparent outline-none transition-all ${darkMode ? 'bg-gray-800 border-gray-700 text-white' : 'bg-gray-50 border-gray-200 text-[#1A1A1A]'}`}
                  >
                    <option value="">Seleccionar...</option>
                    {CAMPAIGN_TYPES.map(t => <option key={t} value={t} className={darkMode ? 'bg-gray-800' : ''}>{t.charAt(0).toUpperCase() + t.slice(1)}</option>)}
                  </select>
                </label>
              </div>

              {/* Task Number & Campaign Name */}
              <div className="space-y-4">
                <label className="block">
                  <span className={`text-xs font-bold uppercase tracking-wider ${darkMode ? 'text-gray-500' : 'text-gray-400'} mb-1 block flex items-center gap-2`}>
                    <Hash size={14} /> Número de Tarea
                  </span>
                  <div className="relative">
                    <span className="absolute left-4 top-1/2 -translate-y-1/2 text-gray-400 font-bold">#</span>
                    <input 
                      type="text" 
                      value={taskNumber} 
                      onChange={(e) => setTaskNumber(e.target.value.replace(/\D/g, ""))}
                      placeholder="1234"
                      className={`w-full border rounded-xl pl-8 pr-4 py-3 focus:ring-2 focus:ring-[#FFD100] focus:border-transparent outline-none transition-all ${darkMode ? 'bg-gray-800 border-gray-700 text-white placeholder:text-gray-600' : 'bg-gray-50 border-gray-200 text-[#1A1A1A]'}`}
                    />
                  </div>
                </label>
              </div>

              <div className="space-y-4">
                <label className="block">
                  <span className={`text-xs font-bold uppercase tracking-wider ${darkMode ? 'text-gray-500' : 'text-gray-400'} mb-1 block flex items-center gap-2`}>
                    <Tag size={14} /> Nombre de la Campaña
                  </span>
                  <input 
                    type="text" 
                    value={campaignName} 
                    onChange={(e) => setCampaignName(e.target.value)}
                    placeholder="Ej: Dinamica Aguila"
                    className={`w-full border rounded-xl px-4 py-3 focus:ring-2 focus:ring-[#FFD100] focus:border-transparent outline-none transition-all ${darkMode ? 'bg-gray-800 border-gray-700 text-white placeholder:text-gray-600' : 'bg-gray-50 border-gray-200 text-[#1A1A1A]'}`}
                  />
                </label>
              </div>

              {/* Date Fields */}
              <div className="flex flex-col gap-1">
                <span className={`text-xs font-bold uppercase tracking-wider ${darkMode ? 'text-gray-500' : 'text-gray-400'} flex items-center gap-2`}>
                  <Calendar size={14} /> Fecha Inicio de Campaña
                </span>
                <input 
                  type="date" 
                  value={startDate} 
                  onChange={(e) => setStartDate(e.target.value)}
                  className={`w-full border rounded-xl px-4 py-3 focus:ring-2 focus:ring-[#FFD100] focus:border-transparent outline-none transition-all ${darkMode ? 'bg-gray-800 border-gray-700 text-white [color-scheme:dark]' : 'bg-gray-50 border-gray-200 text-[#1A1A1A]'}`}
                />
              </div>

              <div className="flex flex-col gap-1">
                <span className={`text-xs font-bold uppercase tracking-wider ${darkMode ? 'text-gray-500' : 'text-gray-400'} flex items-center gap-2`}>
                  <Calendar size={14} /> Fecha Fin de Campaña
                </span>
                <input 
                  type="date" 
                  value={endDate} 
                  onChange={(e) => setEndDate(e.target.value)}
                  className={`w-full border rounded-xl px-4 py-3 focus:ring-2 focus:ring-[#FFD100] focus:border-transparent outline-none transition-all ${darkMode ? 'bg-gray-800 border-gray-700 text-white [color-scheme:dark]' : 'bg-gray-50 border-gray-200 text-[#1A1A1A]'}`}
                />
              </div>

              {/* Primary Objective & Sub Tag */}
              <div className="space-y-4">
                <label className="block">
                  <span className={`text-xs font-bold uppercase tracking-wider ${darkMode ? 'text-gray-500' : 'text-gray-400'} mb-1 block flex items-center gap-2`}>
                    <Target size={14} /> Primary Objective
                  </span>
                  <select 
                    value={primaryObjective} 
                    onChange={(e) => setPrimaryObjective(e.target.value)}
                    className={`w-full border rounded-xl px-4 py-3 focus:ring-2 focus:ring-[#FFD100] focus:border-transparent outline-none transition-all ${darkMode ? 'bg-gray-800 border-gray-700 text-white' : 'bg-gray-50 border-gray-200 text-[#1A1A1A]'}`}
                  >
                    <option value="">Seleccionar...</option>
                    {PRIMARY_OBJECTIVES.map(o => <option key={o} value={o} className={darkMode ? 'bg-gray-800' : ''}>{formatMenuLabel(o)}</option>)}
                  </select>
                </label>
              </div>

              <div className="space-y-4">
                <label className="block">
                  <span className={`text-xs font-bold uppercase tracking-wider ${darkMode ? 'text-gray-500' : 'text-gray-400'} mb-1 block flex items-center gap-2`}>
                    <Tag size={14} /> Sub Tag
                  </span>
                  <select 
                    value={subTag} 
                    onChange={(e) => setSubTag(e.target.value)}
                    disabled={!primaryObjective}
                    className={`w-full border rounded-xl px-4 py-3 focus:ring-2 focus:ring-[#FFD100] focus:border-transparent outline-none transition-all disabled:opacity-50 ${darkMode ? 'bg-gray-800 border-gray-700 text-white' : 'bg-gray-50 border-gray-200 text-[#1A1A1A]'}`}
                  >
                    <option value="">Seleccionar...</option>
                    {primaryObjective && SUB_TAGS[primaryObjective]?.map(t => <option key={t} value={t} className={darkMode ? 'bg-gray-800' : ''}>{formatMenuLabel(t)}</option>)}
                  </select>
                </label>
              </div>

              {/* Activation & Category */}
              <div className="space-y-4">
                <label className="block">
                  <span className={`text-xs font-bold uppercase tracking-wider ${darkMode ? 'text-gray-500' : 'text-gray-400'} mb-1 block flex items-center gap-2`}>
                    <Layers size={14} /> Activation
                  </span>
                  <select 
                    value={activation} 
                    onChange={(e) => setActivation(e.target.value)}
                    disabled={primaryObjective !== "commercial"}
                    className={`w-full border rounded-xl px-4 py-3 focus:ring-2 focus:ring-[#FFD100] focus:border-transparent outline-none transition-all disabled:opacity-50 ${darkMode ? 'bg-gray-800 border-gray-700 text-white' : 'bg-gray-50 border-gray-200 text-[#1A1A1A]'}`}
                  >
                    <option value="">Seleccionar...</option>
                    {primaryObjective === "commercial" ? (
                      ACTIVATIONS.map(a => <option key={a} value={a} className={darkMode ? 'bg-gray-800' : ''}>{formatMenuLabel(a)}</option>)
                    ) : primaryObjective !== "" ? (
                      <option value="n/a" className={darkMode ? 'bg-gray-800' : ''}>n/a</option>
                    ) : (
                      ACTIVATIONS.map(a => <option key={a} value={a} className={darkMode ? 'bg-gray-800' : ''}>{formatMenuLabel(a)}</option>)
                    )}
                  </select>
                </label>
              </div>

              <div className="space-y-4">
                <label className="block">
                  <span className={`text-xs font-bold uppercase tracking-wider ${darkMode ? 'text-gray-500' : 'text-gray-400'} mb-1 block flex items-center gap-2`}>
                    <Grid size={14} /> Category
                  </span>
                  <select 
                    value={category} 
                    onChange={(e) => setCategory(e.target.value)}
                    disabled={primaryObjective !== "commercial"}
                    className={`w-full border rounded-xl px-4 py-3 focus:ring-2 focus:ring-[#FFD100] focus:border-transparent outline-none transition-all disabled:opacity-50 ${darkMode ? 'bg-gray-800 border-gray-700 text-white' : 'bg-gray-50 border-gray-200 text-[#1A1A1A]'}`}
                  >
                    <option value="">Seleccionar...</option>
                    {primaryObjective === "commercial" ? (
                      CATEGORIES.map(c => (
                        <option 
                          key={c} 
                          value={c}
                          className={`${darkMode ? 'bg-gray-800 text-gray-200' : 'bg-white'} ${c === "mktp" ? (darkMode ? "text-[#FFD100] font-bold" : "bg-yellow-50 font-bold") : ""}`}
                        >
                          {formatMenuLabel(c)}
                        </option>
                      ))
                    ) : primaryObjective !== "" ? (
                      <option value="null" className={darkMode ? 'bg-gray-800' : ''}>null</option>
                    ) : (
                      CATEGORIES.map(c => (
                        <option 
                          key={c} 
                          value={c}
                          className={`${darkMode ? 'bg-gray-800 text-gray-200' : 'bg-white'} ${c === "mktp" ? (darkMode ? "text-[#FFD100] font-bold" : "bg-yellow-50 font-bold") : ""}`}
                        >
                          {formatMenuLabel(c)}
                        </option>
                      ))
                    )}
                  </select>
                </label>
              </div>

              {/* Brand Field */}
              <div className="flex flex-col gap-1">
                <div className="flex items-center justify-between h-6">
                  <span className={`text-xs font-bold uppercase tracking-wider ${darkMode ? 'text-gray-500' : 'text-gray-400'} flex items-center gap-2`}>
                    <Award size={14} /> Brand
                  </span>
                  {brands.length < 10 && (
                    <button 
                      onClick={handleAddBrand}
                      className="p-1 rounded-full bg-[#FFD100] text-[#1A1A1A] hover:scale-110 transition-transform"
                    >
                      <Plus size={16} />
                    </button>
                  )}
                </div>
                
                <div className={`space-y-3 max-h-[200px] overflow-y-auto pr-2 ${darkMode ? 'custom-scrollbar-dark' : 'custom-scrollbar'}`}>
                  {brands.map((brand, index) => (
                    <div key={index} className="relative group">
                      <select 
                        value={brand} 
                        onChange={(e) => handleBrandChange(index, e.target.value)}
                        className={`w-full border rounded-xl px-4 py-3 focus:ring-2 focus:ring-[#FFD100] focus:border-transparent outline-none transition-all disabled:opacity-50 ${darkMode ? 'bg-gray-800 border-gray-700 text-white' : 'bg-gray-50 border-gray-200 text-[#1A1A1A]'}`}
                      >
                        <option value="">Seleccionar...</option>
                        {(index === 0 && category && category !== "null" && BRANDS_BY_CATEGORY[category]) ? (
                          BRANDS_BY_CATEGORY[category].map(b => (
                            <option key={b} value={b} className={darkMode ? 'bg-gray-800' : ''}>{b}</option>
                          ))
                        ) : (
                          ALL_BRANDS_UNIQUE.map(b => (
                            <option key={b} value={b} className={darkMode ? 'bg-gray-800' : ''}>{b}</option>
                          ))
                        )}
                      </select>
                      {brands.length > 1 && (
                        <button 
                          onClick={() => handleRemoveBrand(index)}
                          className="absolute right-8 top-1/2 -translate-y-1/2 text-gray-400 hover:text-red-500 opacity-0 group-hover:opacity-100 transition-opacity"
                        >
                          <X size={16} />
                        </button>
                      )}
                    </div>
                  ))}
                </div>
              </div>

              {/* SKU Field (Dynamic List) - Moved next to Brand */}
              <div className="flex flex-col gap-1">
                <div className="flex items-center justify-between h-6">
                  <span className={`text-xs font-bold uppercase tracking-wider ${darkMode ? 'text-gray-500' : 'text-gray-400'} flex items-center gap-2`}>
                    <Hash size={14} /> SKUs
                  </span>
                  {skus.length < 50 && (
                    <button 
                      onClick={handleAddSku}
                      className="p-1 rounded-full bg-[#FFD100] text-[#1A1A1A] hover:scale-110 transition-transform"
                    >
                      <Plus size={16} />
                    </button>
                  )}
                </div>
                
                <div className={`space-y-3 max-h-[200px] overflow-y-auto pr-2 ${darkMode ? 'custom-scrollbar-dark' : 'custom-scrollbar'}`}>
                  {skus.map((sku, index) => (
                    <div key={index} className="relative group">
                      <input 
                        type="text"
                        value={sku}
                        onChange={(e) => handleSkuChange(index, e.target.value)}
                        placeholder={`SKU ${index + 1}`}
                        className={`w-full border rounded-xl px-4 py-3 focus:ring-2 focus:ring-[#FFD100] focus:border-transparent outline-none transition-all disabled:opacity-50 ${darkMode ? 'bg-gray-800 border-gray-700 text-white placeholder:text-gray-600' : 'bg-gray-50 border-gray-200 text-[#1A1A1A]'}`}
                      />
                      {skus.length > 1 && (
                        <button 
                          onClick={() => handleRemoveSku(index)}
                          className="absolute right-3 top-1/2 -translate-y-1/2 text-gray-400 hover:text-red-500 opacity-0 group-hover:opacity-100 transition-opacity"
                        >
                          <X size={16} />
                        </button>
                      )}
                    </div>
                  ))}
                </div>
              </div>

              {/* Channels Field (Checkboxes) */}
              <div className="md:col-span-2 space-y-3">
                <div className="flex items-center justify-between">
                  <span className={`text-xs font-bold uppercase tracking-wider ${darkMode ? 'text-gray-500' : 'text-gray-400'} flex items-center gap-2`}>
                    <Smartphone size={14} /> Channels
                  </span>
                  <button 
                    onClick={() => setIsX2(!isX2)}
                    className={`px-3 py-1.5 text-[11px] font-bold rounded-xl transition-all border flex items-center gap-1.5 select-none ${
                      isX2 
                        ? "bg-[#FFD100] border-[#FFD100] text-[#1A1A1A] font-black scale-105 shadow-sm" 
                        : `${darkMode ? 'bg-gray-800 border-gray-700 text-gray-400' : 'bg-gray-100 border-gray-200 text-gray-600'} hover:border-[#FFD100]/50 active:scale-95`
                    }`}
                  >
                    <span>✖2 CANVAS</span>
                  </button>
                </div>
                <div className={`grid grid-cols-2 sm:grid-cols-3 gap-4 p-4 rounded-xl border ${darkMode ? 'bg-gray-800/50 border-gray-800' : 'bg-gray-50 border-gray-100'}`}>
                  {FORMATS.map(f => (
                    <label key={f} className="flex items-center gap-3 cursor-pointer group">
                      <div className={`w-5 h-5 rounded border flex items-center justify-center transition-all ${
                        selectedFormats.includes(f) 
                          ? "bg-[#FFD100] border-[#FFD100] text-[#1A1A1A]" 
                          : `${darkMode ? 'bg-gray-800 border-gray-600' : 'bg-white border-gray-300'} group-hover:border-[#FFD100]`
                      }`}>
                        {selectedFormats.includes(f) && <Check size={14} strokeWidth={3} />}
                      </div>
                      <input 
                        type="checkbox" 
                        className="hidden" 
                        checked={selectedFormats.includes(f)}
                        onChange={() => toggleFormat(f)}
                      />
                      <span className={`text-sm font-medium transition-colors ${
                        selectedFormats.includes(f) ? (darkMode ? 'text-[#FFD100]' : 'text-[#1A1A1A]') : (darkMode ? 'text-gray-400' : 'text-gray-500')
                      }`}>
                        {f}
                      </span>
                    </label>
                  ))}
                </div>
              </div>
            </div>
          </div>
        </section>

        {/* Right Column: Results */}
        <aside className="space-y-6">
          <div className={`${darkMode ? 'bg-[#1A1A1A] border-gray-800' : 'bg-white border-gray-200'} rounded-2xl p-8 shadow-xl border sticky top-24 transition-colors`}>
            <h2 className={`text-xl font-bold mb-6 flex items-center gap-2 ${darkMode ? 'text-white' : 'text-[#1A1A1A]'}`}>
              <Zap className="text-[#FFD100] w-5 h-5 fill-current" />
              Resultados
            </h2>

            <div className="space-y-8">
              {/* Taxonomy Result */}
              <div>
                <div className="flex items-center justify-between mb-2">
                  <span className={`text-xs font-bold uppercase tracking-widest ${darkMode ? 'text-gray-500' : 'text-gray-400'}`}>Taxonomía Braze</span>
                  {taxonomy && (
                    <button 
                      onClick={() => copyToClipboard(taxonomy, setCopiedTaxo)}
                      className={`hover:text-[#FFD100] transition-colors flex items-center gap-1 text-xs font-bold ${darkMode ? 'text-[#FFD100]' : 'text-gray-600'}`}
                    >
                      {copiedTaxo ? <Check size={14} /> : <Copy size={14} />}
                      {copiedTaxo ? "Copiado" : "Copiar"}
                    </button>
                  )}
                </div>
                <div className={`${darkMode ? 'bg-black border-gray-800 text-[#FFD100]' : 'bg-gray-50 border-gray-200 text-[#1A1A1A]'} border rounded-xl p-4 break-all font-mono text-sm leading-relaxed font-bold min-h-[3rem] flex items-center`}>
                  {taxonomy || <span className={`${darkMode ? 'text-gray-700' : 'text-gray-400'} italic font-normal`}>Esperando selección...</span>}
                </div>
              </div>

              {/* Braze Tags Result */}
              <div>
                <div className="flex items-center justify-between mb-2">
                  <span className={`text-xs font-bold uppercase tracking-widest ${darkMode ? 'text-gray-500' : 'text-gray-400'}`}>Tags para Braze</span>
                  {brazeTags.length > 0 && (
                    <button 
                      onClick={() => copyToClipboard(brazeTags.map(t => t.text).join(", "), setCopiedTags)}
                      className={`hover:text-[#FFD100] transition-colors flex items-center gap-1 text-xs font-bold ${darkMode ? 'text-[#FFD100]' : 'text-gray-600'}`}
                    >
                      {copiedTags ? <Check size={14} /> : <Copy size={14} />}
                      {copiedTags ? "Copiado" : "Copiar"}
                    </button>
                  )}
                </div>
                <div className="flex flex-wrap gap-2 min-h-[3rem] items-center">
                  {brazeTags.length > 0 ? (
                    brazeTags.map((tag, idx) => (
                      <div 
                        key={idx}
                        className={`border rounded-full px-3 py-1 text-[11px] font-medium lowercase transition-all ${
                          tag.type === 'sku'
                            ? (darkMode ? "bg-yellow-500/10 border-yellow-500/30 text-yellow-500" : "bg-yellow-50 border-yellow-200 text-yellow-700")
                            : (darkMode ? "bg-gray-800 border-gray-700 text-gray-400" : "bg-gray-100 border-gray-200 text-gray-600")
                        }`}
                      >
                        {tag.text}
                      </div>
                    ))
                  ) : (
                    <span className={`${darkMode ? 'text-gray-700' : 'text-gray-400'} italic text-sm`}>Esperando selección...</span>
                  )}
                </div>
              </div>

              {/* Excel Control Result */}
              <div className={`pt-6 border-t ${darkMode ? 'border-gray-800' : 'border-gray-100'}`}>
                <div className="flex items-center justify-between">
                  <span className={`text-xs font-bold uppercase tracking-widest ${darkMode ? 'text-gray-500' : 'text-gray-400'}`}>Llevar la fila a Excel</span>
                  {excelRow.trim() && (
                    <button 
                      onClick={() => copyToClipboard(excelRow, setCopiedExcel)}
                      className="bg-[#FFD100] text-[#1A1A1A] px-4 py-2 rounded-lg hover:scale-105 transition-all flex items-center gap-2 text-xs font-bold shadow-lg"
                    >
                      {copiedExcel ? <Check size={14} strokeWidth={3} /> : <FileText size={14} />}
                      {copiedExcel ? "Copiado" : "Copiar Fila"}
                    </button>
                  )}
                </div>
                <p className="text-[10px] text-gray-500 mt-2 italic">
                  * Haz clic en el botón para copiar la fila y pegarla directamente en Excel.
                </p>
              </div>

              {/* Recursos Section */}
              <div className={`pt-6 border-t ${darkMode ? 'border-gray-800' : 'border-gray-100'} space-y-6`}>
                <div className="flex items-center gap-2">
                  <Grid className="text-[#FFD100] w-4 h-4" />
                  <span className={`text-xs font-bold uppercase tracking-widest ${darkMode ? 'text-gray-500' : 'text-gray-400'}`}>Recursos</span>
                </div>

                {/* Imagenes Carousel */}
                <div className="space-y-4">
                  <div className="flex items-center justify-between">
                    <span className="text-[10px] font-bold uppercase text-gray-500">Imágenes de Producto / SKU</span>
                    <div className={`flex rounded-lg p-1 ${darkMode ? 'bg-gray-800' : 'bg-gray-100'}`}>
                      <button 
                        onClick={() => setPreviewImageType("only")}
                        className={`px-2 py-1 text-[9px] font-bold rounded transition-all ${previewImageType === "only" ? "bg-[#FFD100] text-[#1A1A1A]" : (darkMode ? "text-gray-500 hover:text-gray-300" : "text-gray-400 hover:text-gray-600")}`}
                      >
                        SOLITA
                      </button>
                      <button 
                        onClick={() => setPreviewImageType("legal")}
                        className={`px-2 py-1 text-[9px] font-bold rounded transition-all ${previewImageType === "legal" ? "bg-[#FFD100] text-[#1A1A1A]" : (darkMode ? "text-gray-500 hover:text-gray-300" : "text-gray-400 hover:text-gray-600")}`}
                      >
                        LEGAL
                      </button>
                    </div>
                  </div>
                  
                  {selectedSkuDetails.length > 0 ? (
                    <div className="space-y-4">
                      <div className={`relative group border rounded-xl p-4 min-h-[200px] flex flex-col items-center justify-center text-center overflow-hidden transition-all ${darkMode ? 'bg-black/20 border-gray-800' : 'bg-gray-50 border-gray-100'}`}>
                        <img 
                          src={(previewImageType === "legal" ? selectedSkuDetails[currentSkuIndex].imgBees : selectedSkuDetails[currentSkuIndex].imgCrudo) || "https://picsum.photos/seed/placeholder/400/300"} 
                          alt={selectedSkuDetails[currentSkuIndex].name}
                          className="max-h-[150px] object-contain mb-2 rounded-lg"
                          referrerPolicy="no-referrer"
                        />
                        <p className={`text-[10px] font-medium px-4 line-clamp-2 ${darkMode ? 'text-gray-400' : 'text-gray-600'}`}>
                          <span className="text-[#FFD100] font-bold mr-1">{selectedSkuDetails[currentSkuIndex].sku}</span>
                          {selectedSkuDetails[currentSkuIndex].name}
                        </p>
                        
                        {selectedSkuDetails.length > 1 && (
                          <>
                            <div className="absolute inset-y-0 left-2 flex items-center">
                              <button 
                                onClick={() => setCurrentSkuIndex(prev => (prev > 0 ? prev - 1 : selectedSkuDetails.length - 1))}
                                className={`p-1.5 rounded-full transition-all ${darkMode ? 'bg-gray-800/80 text-white hover:bg-[#FFD100] hover:text-[#1A1A1A]' : 'bg-white/80 text-[#1A1A1A] hover:bg-[#FFD100] hover:text-[#1A1A1A] shadow-sm'}`}
                              >
                                <ChevronLeft size={18} />
                              </button>
                            </div>
                            <div className="absolute inset-y-0 right-2 flex items-center">
                              <button 
                                onClick={() => setCurrentSkuIndex(prev => (prev < selectedSkuDetails.length - 1 ? prev + 1 : 0))}
                                className={`p-1.5 rounded-full transition-all ${darkMode ? 'bg-gray-800/80 text-white hover:bg-[#FFD100] hover:text-[#1A1A1A]' : 'bg-white/80 text-[#1A1A1A] hover:bg-[#FFD100] hover:text-[#1A1A1A] shadow-sm'}`}
                              >
                                <ChevronRight size={18} />
                              </button>
                            </div>
                          </>
                        )}
                      </div>

                      <div className="grid grid-cols-1 gap-2">
                        <div className={`border rounded-lg p-3 flex items-center justify-between group hover:border-[#FFD100]/30 transition-all ${darkMode ? 'bg-gray-800/50 border-gray-800' : 'bg-gray-50 border-gray-200'}`}>
                          <div className="flex flex-col">
                            <span className={`text-[10px] uppercase font-bold ${darkMode ? 'text-gray-500' : 'text-gray-400'}`}>1. Imagen producto legal</span>
                            <span className={`text-[9px] truncate max-w-[150px] ${darkMode ? 'text-gray-400' : 'text-gray-500'}`}>{selectedSkuDetails[currentSkuIndex].imgBees || "N/A"}</span>
                          </div>
                          <button 
                            disabled={!selectedSkuDetails[currentSkuIndex].imgBees}
                            onClick={() => copyToClipboard(selectedSkuDetails[currentSkuIndex].imgBees, () => {})}
                            className="text-[10px] text-[#FFD100] font-bold flex items-center gap-1 hover:scale-105 transition-transform disabled:opacity-30"
                          >
                            <Copy size={10} /> Copiar
                          </button>
                        </div>

                        <div className={`border rounded-lg p-3 flex items-center justify-between group hover:border-[#FFD100]/30 transition-all ${darkMode ? 'bg-gray-800/50 border-gray-800' : 'bg-gray-50 border-gray-200'}`}>
                          <div className="flex flex-col">
                            <span className={`text-[10px] uppercase font-bold ${darkMode ? 'text-gray-500' : 'text-gray-400'}`}>2. Imagen product only</span>
                            <span className={`text-[9px] truncate max-w-[150px] ${darkMode ? 'text-gray-400' : 'text-gray-500'}`}>{selectedSkuDetails[currentSkuIndex].imgCrudo || "N/A"}</span>
                          </div>
                          <button 
                            disabled={!selectedSkuDetails[currentSkuIndex].imgCrudo}
                            onClick={() => copyToClipboard(selectedSkuDetails[currentSkuIndex].imgCrudo, () => {})}
                            className="text-[10px] text-[#FFD100] font-bold flex items-center gap-1 hover:scale-105 transition-transform disabled:opacity-30"
                          >
                            <Copy size={10} /> Copiar
                          </button>
                        </div>
                      </div>
                    </div>
                  ) : (
                    <div className={`rounded-xl border p-8 flex flex-col items-center justify-center text-center ${darkMode ? 'bg-gray-800/30 border-gray-800' : 'bg-gray-50 border-gray-100'}`}>
                      <ImageIcon className="w-8 h-8 text-gray-700 mb-2" />
                      <p className="text-[10px] text-gray-600 font-medium italic">Ingresa SKUs válidos para ver recursos</p>
                    </div>
                  )}
                </div>

                {/* Deeplink Section */}
                <div className="space-y-2">
                  <span className={`text-[10px] font-bold uppercase text-gray-500 flex items-center gap-2`}>
                    <LinkIcon size={12} /> Deeplink
                  </span>
                      {selectedSkuDetails.length > 0 ? (
                        <div className={`space-y-3 max-h-[300px] overflow-y-auto pr-2 ${darkMode ? 'custom-scrollbar-dark' : 'custom-scrollbar'}`}>
                          {(() => {
                            // Group SKUs by brand deeplink
                            const groups: Record<string, { skus: SkuInfo[], brandName: string }> = {};
                            
                            selectedSkuDetails.forEach(sku => {
                              const brandUrl = sku.deeplinkBrand || "No Brand";
                              if (!groups[brandUrl]) {
                                // Find brand name from product name
                                let brandName = "Marca";
                                const sortedBrands = [...ALL_BRANDS_UNIQUE].sort((a, b) => b.length - a.length);
                                for (const b of sortedBrands) {
                                  if (sku.name.toLowerCase().includes(b.toLowerCase())) {
                                    brandName = b;
                                    break;
                                  }
                                }
                                groups[brandUrl] = { skus: [], brandName };
                              }
                              groups[brandUrl].skus.push(sku);
                            });

                        return Object.entries(groups).map(([brandUrl, group], groupIdx) => (
                          <div key={groupIdx} className="space-y-2">
                            {brandUrl !== "No Brand" && (
                              <div className={`border rounded-xl p-3 flex items-center justify-between group hover:border-[#FFD100]/30 transition-all ${darkMode ? 'bg-gray-800/50 border-gray-700' : 'bg-gray-50 border-gray-200'}`}>
                                <div className="flex flex-col overflow-hidden">
                                  <span className="text-[9px] text-[#FFD100] font-black uppercase">Deeplink de Marca ({group.brandName})</span>
                                  <span className={`text-[10px] truncate max-w-[180px] ${darkMode ? 'text-gray-300' : 'text-gray-600'}`}>{brandUrl}</span>
                                </div>
                                <button 
                                  onClick={() => copyToClipboard(brandUrl, () => {})}
                                  className="text-[#FFD100] hover:scale-110 transition-transform"
                                >
                                  <Copy size={14} />
                                </button>
                              </div>
                            )}
                            {group.skus.map((sku, skuIdx) => (
                              <div key={skuIdx} className={`border rounded-xl p-3 flex items-center justify-between group hover:border-[#FFD100]/30 transition-all ${darkMode ? 'bg-gray-800/30 border-gray-700' : 'bg-white border-gray-200'}`}>
                                <div className="flex flex-col overflow-hidden">
                                  <span className={`text-[9px] uppercase ${darkMode ? 'text-gray-500' : 'text-gray-400'}`}>Deeplink de SKU ({sku.sku})</span>
                                  <span className={`text-[10px] truncate max-w-[180px] ${darkMode ? 'text-gray-400' : 'text-gray-600'}`}>{sku.deeplink}</span>
                                </div>
                                <button 
                                  onClick={() => copyToClipboard(sku.deeplink, () => {})}
                                  className="text-[#FFD100] hover:scale-110 transition-transform"
                                >
                                  <Copy size={14} />
                                </button>
                              </div>
                            ))}
                          </div>
                        ));
                      })()}
                    </div>
                  ) : (
                    <div className={`border rounded-xl p-3 text-[10px] text-gray-500 italic ${darkMode ? 'bg-gray-800/20 border-gray-800' : 'bg-gray-50 border-gray-200'}`}>
                      Esperando SKUs...
                    </div>
                  )}
                </div>

                {/* Message Extra Section */}
                <div className="space-y-2">
                  <span className="text-[10px] font-bold uppercase text-gray-500 flex items-center gap-2">
                    <Code size={12} /> Message Extra (Liquid)
                  </span>
                  <div className="relative group">
                    <div className={`border rounded-xl p-4 font-mono text-[10px] min-h-[80px] whitespace-pre-wrap break-all transition-all ${darkMode ? 'bg-gray-800 border-gray-700 text-gray-100' : 'bg-gray-100 border-gray-200 text-[#1A1A1A]'}`}>
                      {liquidCode}
                    </div>
                    <button 
                      onClick={() => copyToClipboard(liquidCode, () => {})}
                      className="absolute top-3 right-3 p-1.5 rounded-lg bg-white/5 text-gray-500 opacity-0 group-hover:opacity-100 hover:text-[#FFD100] transition-all"
                    >
                      <Copy size={14} />
                    </button>
                  </div>
                </div>

                {/* Optional Deeplink Section */}
                <div className="space-y-2">
                  <span className="text-[10px] font-bold uppercase text-gray-500 flex items-center gap-2">
                    <LinkIcon size={12} /> Deeplink Opcional
                  </span>
                  <div className="flex gap-2">
                    <select
                      value={selectedOptionalDeeplink}
                      onChange={(e) => setSelectedOptionalDeeplink(e.target.value)}
                      className={`flex-1 border rounded-xl px-3 py-2 text-[10px] outline-none focus:border-[#FFD100]/50 transition-all cursor-pointer ${darkMode ? 'bg-gray-800 border-gray-700 text-gray-200' : 'bg-gray-50 border-gray-200 text-gray-600'}`}
                    >
                      <option value="" className={darkMode ? 'bg-gray-900' : 'bg-[#1A1A1A]'}>Seleccionar recurso...</option>
                      {Object.keys(OPTIONAL_DEEPLINKS).sort().map(name => (
                        <option key={name} value={OPTIONAL_DEEPLINKS[name]} className={darkMode ? 'bg-gray-900' : 'bg-[#1A1A1A]'}>
                          {name}
                        </option>
                      ))}
                    </select>
                    <button
                      disabled={!selectedOptionalDeeplink}
                      onClick={() => copyToClipboard(selectedOptionalDeeplink, setCopiedOptional)}
                      className="p-2 rounded-xl bg-[#FFD100] text-[#1A1A1A] hover:scale-105 transition-all disabled:opacity-30 disabled:hover:scale-100 flex items-center justify-center min-w-[36px]"
                      title="Copiar deeplink"
                    >
                      {copiedOptional ? <Check size={16} strokeWidth={3} /> : <Copy size={16} />}
                    </button>
                  </div>
                  {selectedOptionalDeeplink && (
                    <div className={`border rounded-lg p-2 overflow-hidden ${darkMode ? 'bg-gray-800/50 border-gray-700' : 'bg-gray-50 border-gray-200'}`}>
                      <p className={`text-[9px] truncate ${darkMode ? 'text-gray-500' : 'text-gray-400'}`}>{selectedOptionalDeeplink}</p>
                    </div>
                  )}
                </div>
              </div>
            </div>

            <div className={`mt-8 pt-8 border-t text-center ${darkMode ? 'border-gray-800' : 'border-gray-100'}`}>
              <p className="text-[10px] text-gray-500 uppercase tracking-widest">
                Desarrollado para BEES Online - Digital Comms
              </p>
            </div>
          </div>
        </aside>
      </main>

      {/* Footer */}
      <footer className="max-w-7xl mx-auto px-6 py-12 text-center text-gray-400 text-sm">
        <p>© 2026 TaxoTool - BEES Colombia, desarrollado por Daniel Jiménez de BEES Online. Todos los derechos reservados.</p>
      </footer>
    </div>
  );
}
