# TaxoTool BEES — versión independiente

Esta versión fue preparada para funcionar fuera de Google AI Studio.

## Cambios realizados
- Se eliminó el inicio de sesión obligatorio con Firebase / Google.
- La herramienta abre directamente para cualquier persona que tenga acceso al link.
- No necesita GEMINI_API_KEY.
- La lógica de taxonomía, Braze Tags, SKUs, deeplinks, recursos, modo oscuro, copiar resumen y descarga TXT se conserva.
- Firebase ya no participa en la ejecución de la app.

## Publicarla con GitHub Pages
1. Crea un repositorio nuevo en GitHub.
2. Sube TODO el contenido de esta carpeta al repositorio, incluyendo la carpeta `.github`.
3. Asegúrate de que la rama principal se llame `main`.
4. En GitHub abre `Settings` > `Pages`.
5. En `Build and deployment`, selecciona `GitHub Actions`.
6. Abre la pestaña `Actions` del repositorio. El flujo `Deploy TaxoTool to GitHub Pages` compilará la app automáticamente.
7. Cuando termine, GitHub mostrará el link publicado.

La URL normalmente tendrá una estructura similar a:
`https://TU-USUARIO.github.io/NOMBRE-DEL-REPOSITORIO/`

## Ejecutarla localmente para desarrollo
Requiere Node.js.

```bash
npm install
npm run dev
```

## Generar una carpeta estática manualmente
```bash
npm install
npm run build
```

Esto crea la carpeta `dist`. El contenido de `dist` se puede alojar en cualquier servidor web estático.

## Nota sobre imágenes
La base de SKUs está incluida dentro de la app. Algunas imágenes y recursos visuales apuntan a URLs externas de BEES/Braze; por eso el navegador necesita acceso a internet para mostrarlas.
