# TaxoTool | BEES Colombia

Versión independiente preparada para ejecutarse fuera de Google AI Studio.

- No requiere Gemini.
- No requiere inicio de sesión con Firebase/Google.
- Ejecutar localmente: `npm install` y luego `npm run dev`.
- Compilar: `npm run build`.
- Para instrucciones de publicación, consultar `README_PUBLICAR.md`.
